# -*- coding: utf-8 -*-

"""This is import function scripts."""
from gendiff.utils import gen_diff, parser, stylish  # noqa: F401
