# -*- coding: utf-8 -*-

"""This is import function scripts."""
from gendiff.utils import generate_diff, parser  # noqa: F401
