# -*- coding: utf-8 -*-

"""This is import function scripts."""
from gendiff.generate_diff import get_diff  # noqa: F401

__all__ = 'get_diff'
